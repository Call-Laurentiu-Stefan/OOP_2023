#include "Expression.h"

Expression::~Expression()
{
	delete this;
}
